![动画生涯个人喜好表](https://github.com/itorr/anime-grid/blob/master/simple.jpg?raw=true)

# 🤖「动画生涯个人喜好表生成器」

一个生成 动画生涯个人喜好表 的在线网页工具

230211: 新增超多个格子的 [扩展版](https://lab.magiconch.com/anime-grid/ex.html)

## 地址 

https://lab.magiconch.com/anime-grid/

## 衍生
 - 声豚生涯个人喜好表[@摇曳甜梨](https://weibo.com/3126255377/MsvYizq48)  http://202.43.145.99:8080/sy-grid/index.html
## GitHub
https://github.com/itorr/anime-grid


## 利用
 - 动画信息来自 番组计划 https://bangumi.tv/

禁止 商业、盈利 相关利用
